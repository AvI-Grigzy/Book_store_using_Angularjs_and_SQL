var app = angular.module('bookstoreApp', ['ngRoute']);

app.config(function($routeProvider) {
    $routeProvider
    .when("/", {
        templateUrl: "views/home.html"
    })
    .when("/books", {
        templateUrl: "views/books.html",
        controller: "BooksController"
    })
    .when("/cart", {
        templateUrl: "views/cart.html",
        controller: "CartController"
    })
    .when("/payment", {
        templateUrl: "views/payment.html",
        controller: "PaymentController"
    })
    .when("/login", {
        templateUrl: "views/login.html",
        controller: "LoginController"
    })
    .otherwise({
        redirectTo: "/"
    });
});

// Sample controllers for each page
app.controller('BooksController', function($scope) {
    $scope.books = [
        { title: "1984", price: 15.99, author: "George Orwell" },
        { title: "Harry Potter", price: 9.99, author: "J.K. Rowling" },
        { title: "The Hobbit", price: 14.99, author: "J.R.R. Tolkien" }
    ];

    $scope.addToCart = function(book) {
        alert(book.title + " has been added to the cart!");
    };
});

app.controller('CartController', function($scope) {
    $scope.cartItems = [];
    // Mocked cart functionality
});

app.controller('PaymentController', function($scope) {
    $scope.totalAmount = 50.98;
    $scope.paymentComplete = function() {
        alert('Payment Successful!');
    };
});

app.controller('LoginController', function($scope) {
    $scope.login = function() {
        if ($scope.username && $scope.password) {
            alert('Logged in as ' + $scope.username);
        } else {
            alert('Please enter valid credentials.');
        }
    };
});
